package ysq.weixin.model;

public class MenuEntity {
	private String ToUserName;//接受者微信号
	private String FromUserName;//发送者微信号
	private String CreateTime;//消息创建时间 （整型）
	private String MsgType="event";//event
	private String Event;//事件类型，CLICK
	private String EventKey;//事件KEY值，与自定义菜单接口中KEY值对应
	
	
	public String getToUserName() {
		return ToUserName;
	}
	public void setToUserName(String toUserName) {
		ToUserName = toUserName;
	}
	public String getFromUserName() {
		return FromUserName;
	}
	public void setFromUserName(String fromUserName) {
		FromUserName = fromUserName;
	}
	public String getCreateTime() {
		return CreateTime;
	}
	public void setCreateTime(String createTime) {
		CreateTime = createTime;
	}
	public String getMsgType() {
		return MsgType;
	}
	public void setMsgType(String msgType) {
		MsgType = msgType;
	}
	public String getEvent() {
		return Event;
	}
	public void setEvent(String event) {
		Event = event;
	}
	public String getEventKey() {
		return EventKey;
	}
	public void setEventKey(String eventKey) {
		EventKey = eventKey;
	}
	 
	

	
}
