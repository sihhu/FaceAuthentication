package ysq.weixin.model;
/**
 * 发送通知
 * */
public class SendNotice {

	private String appid;//公众平台账户的AppId；
	private String openid;//贩买用户的OpenId，这个已经放在最终支付结果通知的PostData里了；
	private String transid;//交易单号；
	private String out_trade_no;//第三方订单号；
	private String deliver_timestamp;//发货时间戳，这里指的是Linux时间戳；
	private String deliver_status;//发货状态，1表明成功，0表明失败，失败时需要在deliver_msg填上失败原因；
	private String deliver_msg;//发货状态信息，失败时可以填上UTF8编码的错诨提示信息，比如“该商品已退款”；
	private String app_signature;//根据支付签名（paySign）生成方法中所讲的签名方式生成的，参加签名字段为：appid、appkey、openid、transid、out_trade_no、deliver_timestamp、deliver_status、deliver_msg；
	private String sign_method;//签名方法（不计入签名生成）；
	
	
	public String getAppid() {
		return appid;
	}
	public void setAppid(String appid) {
		this.appid = appid;
	}
	public String getOpenid() {
		return openid;
	}
	public void setOpenid(String openid) {
		this.openid = openid;
	}
	public String getTransid() {
		return transid;
	}
	public void setTransid(String transid) {
		this.transid = transid;
	}
	public String getOut_trade_no() {
		return out_trade_no;
	}
	public void setOut_trade_no(String outTradeNo) {
		out_trade_no = outTradeNo;
	}
	public String getDeliver_timestamp() {
		return deliver_timestamp;
	}
	public void setDeliver_timestamp(String deliverTimestamp) {
		deliver_timestamp = deliverTimestamp;
	}
	public String getDeliver_status() {
		return deliver_status;
	}
	public void setDeliver_status(String deliverStatus) {
		deliver_status = deliverStatus;
	}
	public String getDeliver_msg() {
		return deliver_msg;
	}
	public void setDeliver_msg(String deliverMsg) {
		deliver_msg = deliverMsg;
	}
	public String getApp_signature() {
		return app_signature;
	}
	public void setApp_signature(String appSignature) {
		app_signature = appSignature;
	}
	public String getSign_method() {
		return sign_method;
	}
	public void setSign_method(String signMethod) {
		sign_method = signMethod;
	}
	
	
	
}
