package ysq.weixin.model;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;

public class useValue {
	public final static String AppId ="s";
	public final static String AppSecret ="df";
	public final static String token ="weixin";
	public final static String getTokenUrl ="https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=APPID&secret=APPSECRET";
	public final static String creteMenuUrl ="https://api.weixin.qq.com/cgi-bin/menu/create?access_token=ACCESS_TOKEN";
	public final static String getMenuUrl ="https://api.weixin.qq.com/cgi-bin/menu/get?access_token=ACCESS_TOKEN";
	public final static String deleteMenuUrl ="https://api.weixin.qq.com/cgi-bin/menu/delete?access_token=ACCESS_TOKEN";
	public final static String uploadUrl ="http://file.api.weixin.qq.com/cgi-bin/media/upload?access_token=ACCESS_TOKEN&type=TYPE";
	public final static String getUserNews="https://api.weixin.qq.com/cgi-bin/user/info?access_token=ACCESS_TOKEN&openid=OPENID&lang=zh_CN";
	public final static String getUserTable="https://api.weixin.qq.com/cgi-bin/user/get?access_token=ACCESS_TOKEN&next_openid=NEXT_OPENID";
	public final static String getCodeUrl="https://open.weixin.qq.com/connect/oauth2/authorize?appid=APPID&redirect_uri=REDIRECT_URI&response_type=code&scope=SCOPE&state=STATE#wechat_redirect";
	public final static String getOAuthAccessToken="https://api.weixin.qq.com/sns/oauth2/access_token?appid=APPID&secret=SECRET&code=CODE&grant_type=authorization_code";
	public final static String getreferAccessUrl="https://api.weixin.qq.com/sns/oauth2/refresh_token?appid=APPID&grant_type=refresh_token&refresh_token=REFRESH_TOKEN";
	public final static String getOAuthUserNews="https://api.weixin.qq.com/sns/userinfo?access_token=ACCESS_TOKEN&openid=OPENID&lang=zh_CN";
	public final static String isOAuthAccessToken="https://api.weixin.qq.com/sns/auth?access_token=ACCESS_TOKEN&openid=OPENID";
	
	/**
	 * 用户的AccessToken
	 * */
	public static AccessToken accessToken = null;
	/**
	 * 高级群发地址及值
	 * */
	public final static String sendNewUrl="https://101.226.90.58/cgi-bin/message/custom/send?access_token=ACCESS_TOKEN";
	public final static String sendNewText="{\"touser\":\"OPENID\",\"msgtype\":\"text\",\"text\":{\"content\":\"CONTENT\"}}";
	public final static String sendNewImage="{\"touser\":\"OPENID\",\"msgtype\":\"image\",\"image\":{\"media_id\":\"MEDIA_ID\"}}";
	public final static String sendNewVoice="{\"touser\":\"OPENID\",\"msgtype\":\"voice\",\"voice\":{\"media_id\":\"MEDIA_ID\"}}";
	public final static String sendNewVideo="{\"touser\":\"OPENID\",\"msgtype\":\"video\",\"video\":{\"media_id\":\"MEDIA_ID\",\"title\":\"TITLE\",\"description\":\"DESCRIPTION\"}}";
	public final static String sendNewMusic="{\"touser\":\"OPENID\",\"msgtype\":\"music\",\"music\":{\"title\":\"MUSIC_TITLE\",\"description\":\"MUSIC_DESCRIPTION\",\"musicurl\":\"MUSIC_URL\",\"hqmusicurl\":\"HQ_MUSIC_URL\",\"thumb_media_id\":\"THUMB_MEDIA_ID\"}}";
	public final static String sendNewNews="{\"touser\":\"OPENID\",\"msgtype\":\"news\",\"news\":{\"articles\":[ARTICLES]}}";
	public final static String sendNewNewsContent="{\"title\":\"TITLE\",\"description\":\"DESCRIPTION\",\"url\":\"URL\",\"picurl\":\"PIC_URL\"}";
	/**
	 * 发货通知
	 * */
	public final static String sendNoticeUrl="https://api.weixin.qq.com/pay/delivernotify?access_token=ACCESS_TOKEN";
	public final static String sendNoticeText="{\"appid\":\"APPID\",\"openid\":\"OPENID\",\"transid\":\"TRANSID\",\"out_trade_no\":\"OUT_TRADE_NO\",\"deliver_timestamp\":\"DELIVER_TIMESTAMP\",\"deliver_status\":\"DELIVER_STATUS\",\"deliver_msg\":\"DELIVER_MSG\",\"app_signature\":\"APP_SIGNATURE\",\"sign_method\":\"sha1\"}";
	
	
	public static String path="";
	public final static String textXML = "<xml>"+
	"<ToUserName><![CDATA[%1$s]]></ToUserName>"+
	"<FromUserName><![CDATA[%2$s]]></FromUserName>"+
	"<CreateTime>%3$s</CreateTime>"+
	"<MsgType><![CDATA[%4$s]]></MsgType>"+
	"<Content><![CDATA[%5$s]]></Content>"+
	"<FuncFlag>0</FuncFlag>"+
	"</xml>"; 
	public final static String imageXML = "<xml>"+
	"<ToUserName><![CDATA[%1$s]]></ToUserName>"+
	"<FromUserName><![CDATA[%2$s]]></FromUserName>"+
	"<CreateTime>%3$s</CreateTime>"+
	"<MsgType><![CDATA[%4$s]]></MsgType>"+
	"<Image><MediaId><![CDATA[%5$s]]></MediaId></Image>"+
	"</xml>";  
	
	public final static String voiceXML = "<xml>"+
	"<ToUserName><![CDATA[%1$s]]></ToUserName>"+
	"<FromUserName><![CDATA[%2$s]]></FromUserName>"+
	"<CreateTime>%3$s</CreateTime>"+
	"<MsgType><![CDATA[%4$s]]></MsgType>"+
	"<Voice>" +
	"<MediaId><![CDATA[%5$s]]></MediaId>" +
	"</Voice>"+
	"</xml>";  
	public final static String videoXML = "<xml>"+
	"<ToUserName><![CDATA[%1$s]]></ToUserName>"+
	"<FromUserName><![CDATA[%2$s]]></FromUserName>"+
	"<CreateTime>%3$s</CreateTime>"+
	"<MsgType><![CDATA[%4$s]]></MsgType>"+
	"<Video>" +
	"<MediaId><![CDATA[%5$s]]></MediaId>" +
	"<Title><![CDATA[%6$s]]></Title>" +
	"<Description><![CDATA[%7$s]]></Description>" +
	"</Video>"+
	"</xml>"; 
	public final static String musicXML = "<xml>"+
	"<ToUserName><![CDATA[%1$s]]></ToUserName>"+
	"<FromUserName><![CDATA[%2$s]]></FromUserName>"+
	"<CreateTime>%3$s</CreateTime>"+
	"<MsgType><![CDATA[%4$s]]></MsgType>"+
	"<Music>" +
	"<Title><![CDATA[%5$s]]></Title>" +
	"<Description><![CDATA[%6$s]]></Description>" +
	"<MusicUrl><![CDATA[%7$s]]></MusicUrl>" +
	"<HQMusicUrl><![CDATA[%8$s]]></HQMusicUrl>" +
	"<ThumbMediaId><![CDATA[%9$s]]></ThumbMediaId>" +
	"</Music>"+
	"</xml>"; 
	public final static String textPicXML = "<xml>"+
	"<ToUserName><![CDATA[%1$s]]></ToUserName>"+
	"<FromUserName><![CDATA[%2$s]]></FromUserName>"+
	"<CreateTime>%3$s</CreateTime>"+
	"<MsgType><![CDATA[%4$s]]></MsgType>" +
	"<ArticleCount>%4$s</ArticleCount>" +
	"<Articles>%5$s" +
	"</Articles>"+
	"</xml>"; 
	public final static String textPicContentXML ="<item>" +
	"<Title><![CDATA[%1$s]]></Title>" +
	"<Description><![CDATA[%2$s]]></Description>" +
	"<PicUrl><![CDATA[%3$s]]></PicUrl>" +
	"<Url><![CDATA[%4$s]]></Url>" +
	"</item>";
	public static String getTime(){
		return new Date().getTime()+"";
	}
	/*
	 *设置项目路径
	**/
	public static void setPath(HttpServletRequest request){
		 String url=request.getSession().getServletContext().getRealPath("/");
		 useValue.path=url;
	}
	/**
	 * 
	 * */
	public static String getHeadImg(String url,String dot){
		String[] v=url.split(dot);
		int num=v.length;
		return v[num-1];
	}
	public static void main(String[] args){
		String v=getHeadImg("http://wx.qlogo.cn/mmopen/g3MonUZtNHkdmzicIlibx6iaFqAc56vxLSUfpb6n5WKSYVY0ChQKkiaJSgQ1dZuTOgvLLrhJbERQQ4eMsv84eavHiaiceqxibJxCfHe/0","/");
		System.out.println(v);
	}
}
