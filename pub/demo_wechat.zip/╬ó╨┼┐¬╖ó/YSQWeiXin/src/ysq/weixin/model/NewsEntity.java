package ysq.weixin.model;

import java.util.List;

public class NewsEntity {
	private String ToUserName;//接受者微信号
	private String FromUserName;//发送者微信号
	private String CreateTime;//消息创建时间 （整型）
	private String MsgType="news";//news
	private Integer ArticleCount;//图文消息个数，限制为10条以内
	private List<NewsContent> newsCotentList;
	
	
	public String getToUserName() {
		return ToUserName;
	}
	public void setToUserName(String toUserName) {
		ToUserName = toUserName;
	}
	public String getFromUserName() {
		return FromUserName;
	}
	public void setFromUserName(String fromUserName) {
		FromUserName = fromUserName;
	}
	public String getCreateTime() {
		return CreateTime;
	}
	public void setCreateTime(String createTime) {
		CreateTime = createTime;
	}
	public String getMsgType() {
		return MsgType;
	}
	public void setMsgType(String msgType) {
		MsgType = msgType;
	}
	public Integer getArticleCount() {
		return ArticleCount;
	}
	public void setArticleCount(Integer articleCount) {
		ArticleCount = articleCount;
	}
	public List<NewsContent> getNewsCotentList() {
		return newsCotentList;
	}
	public void setNewsCotentList(List<NewsContent> newsCotentList) {
		this.newsCotentList = newsCotentList;
	}
	
	
	
	
}

