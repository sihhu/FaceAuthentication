package ysq.weixin.service;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface WeiXinService {
	/**
	 * ΢�Žӿ���֤
	 * */
	public boolean checkSignature(HttpServletRequest request, HttpServletResponse response);
	public void weiXinManage(HttpServletRequest request, HttpServletResponse response) throws IOException;
}
