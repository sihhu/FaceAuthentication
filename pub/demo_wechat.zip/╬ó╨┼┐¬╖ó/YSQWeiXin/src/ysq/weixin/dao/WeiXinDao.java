package ysq.weixin.dao;

import ysq.weixin.model.EventEntity;

import ysq.weixin.model.MenuEntity;
import ysq.weixin.model.TextEntity;

public interface WeiXinDao {
	/**
	 * 文本内消息处理
	 * */
	public String doTextNew(TextEntity textEntity);
	
	/**
	 * 订阅处理
	 * @throws Exception 
	 * */
	public String doSubscribe(EventEntity eventEntity);

	/** 
	 * 菜单点击处理
	 * @throws Exception 
	 * */
	public String doMenuClick(MenuEntity menuEntity);
}
